import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateAccountPage extends BasePage {
    @FindBy(id = "firstname")
    static WebElement firstNameField;

    @FindBy(id = "lastname")
    static WebElement lastNameField;

    @FindBy(id = "email_address")
    static WebElement emailField;

    @FindBy(id = "password")
    static WebElement passwordField;

    @FindBy(id = "password-confirmation")
    static WebElement confirmPasswordField;

    @FindBy(xpath = "//button[@class='action submit primary']")
    private WebElement createAccountButton;

    @FindBy(xpath = "//div[contains(text(),'Thank you for registering with Fake Online Clothing Store')]")
    static WebElement successRegistrationMsg;

    @FindBy(xpath = "//div[contains(text(),'There is already an account with this email address.')]")
	static WebElement emailAlreadyExistsError;

    @FindBy(xpath = "//div[contains(text(),'Please enter a valid email address')]")
    static WebElement validEmailError;

    @FindBy(xpath = "//div[contains(text(),'Minimum of different classes of characters in password is 3.')]")
    static WebElement strongPasswordError;

    @FindBy(xpath = "//div[contains(text(),'Please enter the same value again.')]")
    static WebElement passwordConfirmError;

    public CreateAccountPage(WebDriver driver) {
        super(driver);
    }

    public void fillOutForm(String firstName, String lastName, String email, String password, String confirmPassword) {
        firstNameField.sendKeys(firstName);
        lastNameField.sendKeys(lastName);
        emailField.sendKeys(email);
        passwordField.sendKeys(password);
        confirmPasswordField.sendKeys(confirmPassword);
    }

    public void clickCreateAccount() {
        createAccountButton.click();
    }
}