import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


    

public class CreateAccountTest extends ExcelUtils {
	
	private WebDriver driver;
    private CreateAccountPage createAccountPage;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String confirmPassword;

    private static final String EMAIL_REGEX =
            "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    public static boolean isValidEmail(String email) {
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }
    
    private static final String PASSWORD_REGEX =
    		"^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$";
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);

    public static boolean isValidPassword(String password) {
        Matcher matcher = PASSWORD_PATTERN.matcher(password);
        return matcher.matches();
    }
    
    
	@Before
	public void setUp() {
	        String cDriver="C:\\Program Files\\selenium-java-3.13.0\\chromedriver_win32\\chromedriver.exe";
	        System.setProperty("webdriver.chrome.driver", cDriver);
	        driver = new ChromeDriver();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("https://magento.softwaretestingboard.com/customer/account/create/");
	        createAccountPage = new CreateAccountPage(driver);

	        }
	
	@Test(dataProvider = "getTestData")
    public void createAccount(String firstName, String lastName, String email, String password, String confirmPassword) {
        
        CreateAccountPage createAccountPage = PageFactory.initElements(driver, CreateAccountPage.class);
        createAccountPage.fillOutForm(firstName, lastName, email, password, confirmPassword);
        createAccountPage.clickCreateAccount();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        
        if(CreateAccountPage.successRegistrationMsg.isDisplayed())
        {
        	String successMsg= CreateAccountPage.successRegistrationMsg.getText();
            assertTrue(successMsg.contains("Thank you for registering with Fake Online Clothing Store"));
        }
        else if(!isValidEmail(CreateAccountPage.emailField.getText())) {
        	String successMsg= CreateAccountPage.validEmailError.getText();
            assertTrue(successMsg.contains("Please enter a valid email address"));
        }
        else if(CreateAccountPage.emailAlreadyExistsError.isDisplayed()) {
        	String successMsg= CreateAccountPage.emailAlreadyExistsError.getText();
            assertTrue(successMsg.contains("There is already an account with this email address."));
        }
        else if(CreateAccountPage.passwordField!= CreateAccountPage.confirmPasswordField) {
        	String successMsg= CreateAccountPage.passwordConfirmError.getText();
            assertTrue(successMsg.contains("Please enter the same value again."));
        }
        else if(!isValidPassword(CreateAccountPage.passwordField.getText())) {
        	String successMsg= CreateAccountPage.strongPasswordError.getText();
            assertTrue(successMsg.contains("Minimum length of this field must be equal or greater than 8 symbols."));
        }

        driver.quit();
    }
	

    @DataProvider(name="getTestData")
    public static Object[][] getTestData() {
            FileInputStream fileInputStream = null;
            Workbook workbook = null;
            try {
            fileInputStream = new FileInputStream(TEST_DATA_FILE_PATH);
            workbook = WorkbookFactory.create(fileInputStream);
            } catch (FileNotFoundException e) {
            e.printStackTrace();
            } catch (IOException e) {
            e.printStackTrace();
            }

            Sheet sheet = workbook.getSheet(TEST_DATA_SHEET_NAME);

            Object[][] testData = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);

            for (int j = 0; j < row.getLastCellNum(); j++) {
            Cell cell = row.getCell(j);

            switch (cell.getCellType()) {
            case STRING:
            testData[i - 1][j] = cell.getStringCellValue();
            break;
            case NUMERIC:
            testData[i - 1][j] = cell.getNumericCellValue();
            break;
            }
            }
            }

            return testData;
            }
    @After
    public void tearDown() {
            driver.quit();
            }
 }

