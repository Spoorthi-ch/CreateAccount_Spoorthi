import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtils{
    static final String TEST_DATA_FILE_PATH = "C:\\Users\\User\\Desktop\\TestDataCreateAccount.xlsx";
    static final String TEST_DATA_SHEET_NAME = "CreateAccountTestData";

    public static Object[][] getTestData() {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        try {
            fileInputStream = new FileInputStream(TEST_DATA_FILE_PATH);
            workbook = WorkbookFactory.create(fileInputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Sheet sheet = workbook.getSheet(TEST_DATA_SHEET_NAME);

        Object[][] testData = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);

            for (int j = 0; j < row.getLastCellNum(); j++) {
                Cell cell = row.getCell(j);

                switch (cell.getCellType()) {
                    case STRING:
                        testData[i - 1][j] = cell.getStringCellValue();
                        break;
                    case NUMERIC:
                        testData[i - 1][j] = cell.getNumericCellValue();
                        break;
                }
            }
        }

        return testData;
    }
}
